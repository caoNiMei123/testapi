

#include <ngx_config.h>
#include <ngx_core.h>
#include <ngx_http.h>
#include "genimage.h"
#include "vcode.h"

#define ngx_http_cycle_get_module_loc_conf(cycle, module)                    \
    (cycle->conf_ctx[ngx_http_module.index] ? ((ngx_http_conf_ctx_t *) cycle->conf_ctx[ngx_http_module.index])->loc_conf[module.ctx_index]: NULL)


typedef struct {
    ngx_uint_t  image_buf_size; //图片buf大小
    ngx_uint_t  image_height; //图片输出高度
    ngx_uint_t  image_width; //图片输出宽度
    ngx_str_t   font_img_path; //图片目录 
    ngx_str_t   image_secret_key; //私钥    
    ngx_flag_t  vcode_inited;  //是否初始化  
} ngx_http_vcode_loc_conf_t;

static ngx_int_t ngx_http_vcode_handler(ngx_http_request_t *r);
static ngx_int_t ngx_http_vcode_init(ngx_conf_t *cf);
static void *ngx_http_vcode_create_loc_conf(ngx_conf_t *cf);
static char *ngx_http_vcode_merge_loc_conf(ngx_conf_t *cf, void *parent, void *child);

static ngx_command_t  ngx_http_vcode_commands[] = {
    { 
        ngx_string("genimage"),
        NGX_HTTP_LOC_CONF|NGX_CONF_NOARGS,
        ngx_http_vcode_init,
        0,
        0,
        NULL 
    },
    { 
        ngx_string("vcode_image_buf_size"),
        NGX_HTTP_MAIN_CONF|NGX_HTTP_SRV_CONF|NGX_HTTP_LOC_CONF|NGX_CONF_TAKE1,
        ngx_conf_set_num_slot,
        NGX_HTTP_LOC_CONF_OFFSET,
        offsetof(ngx_http_vcode_loc_conf_t, image_buf_size),
        NULL
    },

    { 
        ngx_string("vcode_image_height"),
        NGX_HTTP_MAIN_CONF|NGX_HTTP_SRV_CONF|NGX_HTTP_LOC_CONF|NGX_CONF_TAKE1,
        ngx_conf_set_num_slot,
        NGX_HTTP_LOC_CONF_OFFSET,
        offsetof(ngx_http_vcode_loc_conf_t, image_height),
        NULL
    },

    { 
        ngx_string("vcode_image_width"),
        NGX_HTTP_MAIN_CONF|NGX_HTTP_SRV_CONF|NGX_HTTP_LOC_CONF|NGX_CONF_TAKE1,
        ngx_conf_set_num_slot,
        NGX_HTTP_LOC_CONF_OFFSET,
        offsetof(ngx_http_vcode_loc_conf_t, image_width),
        NULL
    },
    
    { 
        ngx_string("vcode_image_path"),
        NGX_HTTP_MAIN_CONF|NGX_HTTP_SRV_CONF|NGX_HTTP_LOC_CONF|NGX_CONF_TAKE1,
        ngx_conf_set_str_slot,
        NGX_HTTP_LOC_CONF_OFFSET,
        offsetof(ngx_http_vcode_loc_conf_t, font_img_path),
        NULL 
    },
    { 
        ngx_string("vcode_image_secret_key"),
        NGX_HTTP_MAIN_CONF|NGX_HTTP_SRV_CONF|NGX_HTTP_LOC_CONF|NGX_CONF_TAKE1,
        ngx_conf_set_str_slot,
        NGX_HTTP_LOC_CONF_OFFSET,
        offsetof(ngx_http_vcode_loc_conf_t, image_secret_key),
        NULL 
    },
    ngx_null_command
};


static ngx_http_module_t  ngx_http_vcode_module_ctx = {
    NULL,                                  /* preconfiguration */
    NULL,                     /* postconfiguration */
    NULL,                                  /* create main configuration */
    NULL,                                  /* init main configuration */
    NULL,                                  /* create server configuration */
    NULL,                                  /* merge server configuration */
    ngx_http_vcode_create_loc_conf,          /* create location configuration */
    ngx_http_vcode_merge_loc_conf            /* merge location configuration */
};


ngx_module_t  ngx_http_vcode_module = {
    NGX_MODULE_V1,
    &ngx_http_vcode_module_ctx,              /* module context */
    ngx_http_vcode_commands,                 /* module directives */
    NGX_HTTP_MODULE,                       /* module type */
    NULL,                                  /* init master */
    NULL,                                  /* init module */    
    NULL,                                   /* init process */
    NULL,                                  /* init thread */
    NULL,                                  /* exit thread */
    NULL,                                  /* exit process */
    NULL,                                  /* exit master */
    NGX_MODULE_V1_PADDING
};



static ngx_int_t ngx_http_vcode_handler(ngx_http_request_t *r)
{
    ngx_http_vcode_loc_conf_t  *vlcf = ngx_http_get_module_loc_conf(r, ngx_http_vcode_module);
    if(0 == vlcf->vcode_inited ){
        vlcf->vcode_inited = 1;
        if(vlcf->image_buf_size == NGX_CONF_UNSET_UINT)
        {
            vlcf->vcode_inited = 0;
            return NGX_HTTP_INTERNAL_SERVER_ERROR;
        }   
        //初始化genimage
        int ret = genimage_init(vlcf->font_img_path.data, vlcf->image_width, vlcf->image_height, 0, IMGCAPTCHA_NORMAL_FONT | IMGCAPTCHA_SPECIAL_FONT| IMGCAPTCHA_MANUAL_FONT, IMGCAPTCHA_SET_CURVE | IMGCAPTCHA_SET_LEN );
        if(ret < 0)
        {
            vlcf->vcode_inited = 0;
            return NGX_HTTP_INTERNAL_SERVER_ERROR;
        }
        //初始化vcode
        vcode_init(1, "ABCDEFGHJKLMNPQRSTUVWXYZ23456789", 4, 6);
    }
    
    ngx_int_t rc;
    ngx_buf_t *b;
    char vcode[1024] = {0};
    char vcode_split[1024] = {0};
    char vcode_str[10] = {0};
    ngx_int_t size = 0;
    ngx_chain_t out;
    b = ngx_calloc_buf(r->pool);
    if(b == NULL)
    {
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }
    
    //vcode_gen(vcode, 1024, vlcf->image_secret_key.data);
    if(r->args.len > 1024 || r->args.len < 32){
        return NGX_HTTP_FORBIDDEN;
    }
    //反解出签名中的字符串
    strncpy(vcode,r->args.data,r->args.len);
    char * split = strtok(vcode, "&");
    strcpy(vcode_split , split);
    vcode_getstr(vcode_split,vcode_str);  
    u_char * p = ngx_palloc(r->connection->pool, vlcf->image_buf_size);
    if (p == NULL) 
    {
        return NGX_HTTP_INTERNAL_SERVER_ERROR;
    }
    b->start = b->pos = p;
    b->end = b->last = p + vlcf->image_buf_size;
    b->temporary = 1;
    b->last_buf = 1;
    //通过字符串生成图片 
    size = captcha_gen(0, vcode_str, 4, b->pos, vlcf->image_buf_size);
    if(size < 0 )
    {
        return NGX_HTTP_INTERNAL_SERVER_ERROR;      
    }
    out.buf = b;
    out.next = NULL;    
    b->last = b->pos + size;   
    r->headers_out.status = NGX_HTTP_OK;
    r->headers_out.content_length_n = size;
    r->headers_out.content_type.len = strlen("image/jpeg");
    r->headers_out.content_type.data = (u_char *) "image/jpeg"; 
    rc = ngx_http_send_header(r);
    if(rc != NGX_OK)
    {
        return rc;
    }
    return ngx_http_output_filter(r, &out);
    
}


static void * ngx_http_vcode_create_loc_conf(ngx_conf_t *cf)
{
    ngx_http_vcode_loc_conf_t  *conf;
    conf = ngx_pcalloc(cf->pool, sizeof(ngx_http_vcode_loc_conf_t));
    if (conf == NULL) {
        return NULL;
    }
    conf->image_buf_size = NGX_CONF_UNSET_UINT;
    conf->image_height = NGX_CONF_UNSET_UINT;
    conf->image_width = NGX_CONF_UNSET_UINT;
    conf->vcode_inited = 0;
    return conf;
}


static char * ngx_http_vcode_merge_loc_conf(ngx_conf_t *cf, void *parent, void *child)
{

    ngx_http_vcode_loc_conf_t  *prev = parent;
    ngx_http_vcode_loc_conf_t  *conf = child;
    ngx_conf_merge_uint_value(conf->image_buf_size,prev->image_buf_size, 1024000);  
    ngx_conf_merge_uint_value(conf->image_height,prev->image_height, 40);   
    ngx_conf_merge_uint_value(conf->image_width,prev->image_width, 120);    
    ngx_conf_merge_str_value(conf->font_img_path, prev->font_img_path,""); 
    ngx_conf_merge_str_value(conf->image_secret_key, prev->image_secret_key, ""); 
    conf->vcode_inited = 0;   
    return NGX_CONF_OK;
}


static ngx_int_t ngx_http_vcode_init(ngx_conf_t *cf)
{
    ngx_http_core_loc_conf_t  *clcf = ngx_http_conf_get_module_loc_conf(cf, ngx_http_core_module);
    clcf->handler = ngx_http_vcode_handler;
    return NGX_CONF_OK;
}
