/***************************************************************************
 * 
 * Copyright (c) 2008 Baidu.com, Inc. All Rights Reserved
 * $Id: genimage.cpp,v 1.7 2008/06/30 12:56:09 wenlf Exp $ 
 * 
 **************************************************************************/
/**
 * @file genimage.cpp
 * @author wenlf(com@baidu.com)
 * @date 2008/04/30 16:49:17
 * @version $Revision: 1.7 $ 
 * @brief 输入N个字符,生成相应的验证码
 *  
 **/

#include "genimage.h"
#include "gd.h"
#include "gdfontl.h"
#include "gdfontg.h"
#include "gdfontmb.h"
#include "gdfonts.h"
#include "gdfontt.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <ctype.h>
#include <time.h>
#include <errno.h>
#include <sys/time.h>
#include <unistd.h>
#include <sys/types.h>
#include <netinet/tcp.h>

#define IMGCAPTCHA_WIDTH 120
#define IMGCAPTCHA_HEIGHT 40

#define IMGCAPTCHA_SCALE_MIN 18

#define IMGCAPTCHA_CHAR_MAX_HEIGHT 35		//最大的高度
#define IMGCAPTCHA_CHAR_MIN_WIDTH  5		//最小的宽度
#define PI 3.1416
#define IMGCAPTCHA_CHAR_MIN_GAP 1			//字符间距最小值
#define IMGCAPTCHA_BEZIER_POINT_NUM 4		//bizer曲线控制点个数
#define IMGCAPTCHA_STR_CODE_MAX_WIDTH  (IMGCAPTCHA_WIDTH - 4)	//字符串重叠后的最大总长度
#define IMGCAPTCHA_STR_CODE_MIN_WIDTH     40	//字符串重叠后的最小总长度
#define IMGCAPTCHA_OVERLAP_CHAR_MIN_HEIGHT      15	//最小的高度
#define IMGCAPTCHA_OVERLAP_CHAR_MIN_WIDTH       5	//最小的宽度
#define IMGCAPTCHA_SIZE_BADCASE_LIST            "MWHK"	// 这四个字符很容易在较大字符的情况下超出CHAR_MAX_HEIGHT
/* const macro var */


#define IMGCAPTCHA_FN_CFG		"captcha.conf"	//配置文件
#define IMGCAPTCHA_FN_CFG_MEM	"./conf/captcha.mem"	//配置文件

#define IMGCAPTCHA_LOG_FN	"genimage."
#define IMGCAPTCHA_LOG_MAX_LEN	10*1024*1024
#define IMGCAPTCHA_PORT_DEFAULT_BASE 4030

#define IMGCAPTCHA_IMG_MAXSIZE  1024*10



enum imgcaptcha_font_type_enum_t {
	fontManuscript = 1,
	fontSpecial = 2,
	fontNormal = 3
};
typedef struct _imgcaptcha_font_item_t {
	char path[256];
	int type;					// font_type_enum_t
}imgcaptcha_font_item_t;

typedef struct  _imgcaptcha_font_attr {
	double sz;
	double angle;
	int wid;
	int hei;
	int locx;
	int locy;
} imgcaptcha_font_attr;

typedef struct _imgcaptcha_str_rect {
	int lx;
	int rx;
	int by;
	int ty;
} imgcaptcha_str_rect;

enum imgcaptcha_curve_pos {
	TOP = 0,
	BOTTOM = 1,
	TOP_LEFT = 2,
	TOP_RIGHT = 3,
	BOTTOM_LEFT = 4,
	BOTTOM_RIGHT = 5
};

typedef struct _imgcaptcha_line_point {
	int x;
	int y;
} imgcaptcha_line_point;

static imgcaptcha_font_item_t g_imgcaptcha_fonts[IMGCAPTCHA_FONT_MAXNUM];
static imgcaptcha_cfg_data_t g_imgcaptcha_cfg_data;
static char g_imgpath[IMGCAPTCHA_PIC_MAXNUM][256];
static gdImagePtr g_gdimg[IMGCAPTCHA_PIC_MAXNUM];
static int g_picnum = 0;
static int g_fontsnum = 0;
static int ul_fexist(const char *path, const char *fname);
static int char_in_str(char *str, int len, char ch);
static void draw_deCasteljau(gdImagePtr im, imgcaptcha_line_point * point, int len, int color);
static void lens_image(gdImagePtr im, gdImagePtr imtmp);
static void checkpoint(imgcaptcha_line_point * point);
static int get_curve_loc(imgcaptcha_str_rect rect, int left, const char buf[4]);
static void get_bezier_point(imgcaptcha_line_point point[4], imgcaptcha_str_rect sr, int pos);
static int get_font_wh(int brect[8], int *wid, int *hei);
static int in_badcaselist(char ch, char nextch);
static int image_string(gdImagePtr im, gdImagePtr imtmp, imgcaptcha_font_attr font[4], const char *strbuf,
				 imgcaptcha_str_rect *sr, int ignoreout);
static int image_string_tmp(gdImagePtr imtmp, imgcaptcha_font_attr font[4], const char strbuf[4], char *fontpath,
					 int color, const int fontmaxsz, const int fontminsz, int maxangle, int *left);

/**     
 * @brief   判断单个字符是否在目标串中
 *
 * @param[in]   str：目标串
 *              len: 目标串的长度
 *              ch: 单个字符
 *
 * @return  always return NULL
 */
static int
char_in_str(char *str, int len, char ch)
{
	if (NULL == str || len <= 0)
		return 0;
	int i = 0;
	for (i = 0; i < len; i++) {
		if (*(str + i) == ch)
			return 1;
	}
	return 0;
}


static int ul_fexist(const char *path, const char *fname)
{
	size_t size = 256;
	char full_path[256] = {0};
	
	struct stat statbuf;
	size_t path_len = strlen(path);
	int ret = 0;
	if (path_len > 0) {
		path_len --; 
		while(path_len > 0 && '/' == path[path_len])
		{
			path_len--;
		}    
		if (path_len >= size) 
		{ 
			return 0; 
		}    
		memcpy(full_path, path, path_len+1);
	} else {
		if (fname[0] != '/') {
			ret = snprintf(full_path, size, "%s", fname);
			if ((size_t)ret >= size) 
			{
				return 0; 
			}   
		}    
		full_path[0] = '/';
	}   
	while (*fname != '\0' && '/' == *fname) {
		fname++;
	}

	if ('/' == full_path[path_len]) {
		ret = snprintf(full_path + path_len + 1, size - path_len - 1, "%s", fname);
	} else {
		ret = snprintf(full_path + path_len + 1, size - path_len - 1, "/%s", fname);
	}
	if (ret + path_len + 1 >= size) {
		return 0;
	}    

	if (stat(full_path, &statbuf) == -1) {
		return 0;
	}
	if(!S_ISREG(statbuf.st_mode)) {
		return 0;
	}
	return 1;


}

static void
loadg_fonts()
{
	memset(g_imgcaptcha_fonts, 0, sizeof(g_imgcaptcha_fonts));
	char fname[128];
	int i = 0;
	for (i = 0; g_imgcaptcha_cfg_data.enable_fn && i < IMGCAPTCHA_FONT_MAXNUM; i++) {
		sprintf(fname, "fn_%d.ttf", i);
		if (ul_fexist(g_imgcaptcha_cfg_data.font_path, fname) == 1) {
			g_imgcaptcha_fonts[g_fontsnum].type = fontNormal;
			sprintf(g_imgcaptcha_fonts[g_fontsnum++].path, "%s/%s", g_imgcaptcha_cfg_data.font_path, fname);
		}
	}
	for (i = 0; g_imgcaptcha_cfg_data.enable_fs && i < IMGCAPTCHA_FONT_MAXNUM; i++) {
		sprintf(fname, "fs_%d.ttf", i);
		if (ul_fexist(g_imgcaptcha_cfg_data.font_path, fname) == 1) {
			g_imgcaptcha_fonts[g_fontsnum].type = fontSpecial;
			sprintf(g_imgcaptcha_fonts[g_fontsnum++].path, "%s/%s", g_imgcaptcha_cfg_data.font_path, fname);
		}
	}
	for (i = 0; g_imgcaptcha_cfg_data.enable_fm && i < IMGCAPTCHA_FONT_MAXNUM; i++) {
		sprintf(fname, "fm_%d.ttf", i);
		if (ul_fexist(g_imgcaptcha_cfg_data.font_path, fname) == 1) {
			g_imgcaptcha_fonts[g_fontsnum].type = fontManuscript;
			sprintf(g_imgcaptcha_fonts[g_fontsnum++].path, "%s/%s", g_imgcaptcha_cfg_data.font_path, fname);
		}
	}
}


static void
loadg_imgpath()
{
	memset(g_imgpath, 0, sizeof(g_imgpath));
	char fname[128];
	int i = 0;
	for (i = 0; i < IMGCAPTCHA_PIC_MAXNUM; i++) {
		sprintf(fname, "g%d.jpg", i);
		if (ul_fexist(g_imgcaptcha_cfg_data.font_path, fname) == 1) {
			sprintf(g_imgpath[g_picnum++], "%s/%s", g_imgcaptcha_cfg_data.font_path, fname);
		}
	}
}


static int
grayimg_init()
{
	loadg_fonts();
	loadg_imgpath();

	memset(g_gdimg, 0, sizeof(g_gdimg));
	int i = 0;
	for (i = 0; i < g_picnum; i++) {
		g_gdimg[i] = NULL;
		FILE *fimg = fopen(g_imgpath[i], "rb");
		if (fimg) {
			gdImagePtr im = gdImageCreateFromJpeg(fimg);
			if (im) {
				g_gdimg[i] = im;
			} 
			fclose(fimg);
		} 
	}
	if (0 == g_fontsnum || 0 == g_picnum) {
		return -1;
	}
	return 0;
}


int
genimage_init(const char *sample_path, int width, int height, int sample_size,
			  unsigned int sample_type, unsigned int captcha_stlye)
{
	if(NULL == sample_path){
		return -1;
	} 
	if((sample_type & ~IMGCAPTCHA_MANUAL_FONT & ~IMGCAPTCHA_SPECIAL_FONT & ~IMGCAPTCHA_NORMAL_FONT) > 0){
		return -1;
	}

	if((captcha_stlye & ~IMGCAPTCHA_SET_CURVE & ~IMGCAPTCHA_SET_LEN & ~IMGCAPTCHA_SET_BG 
				& ~IMGCAPTCHA_SET_DEFAULT ) > 0){
		return -1;
	}

	memset(&g_imgcaptcha_cfg_data, 0, sizeof(g_imgcaptcha_cfg_data));
	snprintf(g_imgcaptcha_cfg_data.font_path, sizeof(g_imgcaptcha_cfg_data.font_path), "%s", sample_path);

	g_imgcaptcha_cfg_data.width = width;
	g_imgcaptcha_cfg_data.height = height;

	//手写体
	g_imgcaptcha_cfg_data.enable_fm = sample_type & IMGCAPTCHA_MANUAL_FONT;

	//特别字体
	g_imgcaptcha_cfg_data.enable_fs = sample_type & IMGCAPTCHA_SPECIAL_FONT;

	//normal fonts
	g_imgcaptcha_cfg_data.enable_fn = sample_type & IMGCAPTCHA_NORMAL_FONT;

	//使用背景图
	g_imgcaptcha_cfg_data.bgimg = captcha_stlye & IMGCAPTCHA_SET_BG;

	//是否采用变形
	g_imgcaptcha_cfg_data.enable_lens = captcha_stlye & IMGCAPTCHA_SET_LEN;

	//使用干扰线
	g_imgcaptcha_cfg_data.enable_curve = captcha_stlye & IMGCAPTCHA_SET_CURVE;

	//干扰线起伏程度
	g_imgcaptcha_cfg_data.curve_level = 20;

	//gd库写字符时的最大size
	g_imgcaptcha_cfg_data.char_max_scale_size = 28;

	//最大的旋转角度
	g_imgcaptcha_cfg_data.max_angle = 30;

	//水平重合像素的个数    1-4 推荐2或者3
	g_imgcaptcha_cfg_data.overlap_pixel_num = 2;

	//重合程度
	g_imgcaptcha_cfg_data.overlap_rate = 60;

	//重合点之间的高度控制  0-100 0不重合 100 完全重合 避免出现H3 这种字符粘接
	g_imgcaptcha_cfg_data.height_overlap_rate = 60;

	g_imgcaptcha_cfg_data.lens_deformation_level = 20;

	snprintf(g_imgcaptcha_cfg_data.curve_badcase_list, sizeof(g_imgcaptcha_cfg_data.curve_badcase_list), "%s", "EFHMNTUWX");

	snprintf(g_imgcaptcha_cfg_data.overlap_badcase_list, sizeof(g_imgcaptcha_cfg_data.overlap_badcase_list),
			 "%s", "W:WN H:NM K:N M:MN N:NMKT");
	sample_size = 0;

	srand(time(NULL));

	if (grayimg_init() < 0) {
		return -1;
	}
	return 0;
}

/*
 *  生成字符重叠的验证码
 *  接口与grayimg_gen 一致
 *  基本方法：先将字符写在一个临时buf中，然后计算字符之间的距离，进行平移重叠，最后映射到
 *  验证码图像空间。增加鱼眼变形，增加bezier干扰曲线
 *
 *
 */
static int
overlap_grayimg_gen(const char *strcode, int code_len, char *pimgdata_buf, const int bufsize)
{
	code_len = 4;
	imgcaptcha_font_item_t *pfontitem = NULL;
	gdImagePtr imtmp = NULL, pmemimg = NULL, im = NULL, imbg = NULL;

	//创建临时字符区域，用于写字符后计算宽度高度，做相应调整，然后复制到im
	imtmp = gdImageCreate(IMGCAPTCHA_WIDTH * 3, IMGCAPTCHA_HEIGHT * 3);
	if (!imtmp) {
		return -1;
	}

	static unsigned int img_i = 0;
	static unsigned int font_i = 0;

	if(0 == g_picnum || 0 == g_fontsnum){
	   return -1;
	}
	pmemimg = g_gdimg[(img_i++) % g_picnum];
	pfontitem = &g_imgcaptcha_fonts[(font_i++) % g_fontsnum];
	if (!pmemimg || !pfontitem) {
		return -1;
	}
	//背景色和字体颜色
	int white, black;

	int fontcolor;

	//记录四个字符在临时图像区域中的位置
	imgcaptcha_font_attr font[4];

	int left = 1;				//默认左边字体比右边大

	int fontmaxsz = g_imgcaptcha_cfg_data.char_max_scale_size;	//字体最大的size
	int fontminsz = IMGCAPTCHA_SCALE_MIN;	//字体最小的size
	int maxangle = g_imgcaptcha_cfg_data.max_angle * 2;	//角度的变化区域(-20 ~ 20)

	int i;

	white = gdImageColorResolve(imtmp, 255, 255, 255);
	black = gdImageColorResolve(imtmp, 0, 0, 0);

	int degree = rand() % 20;
	fontcolor = gdImageColorResolve(imtmp, degree, degree, degree);

	//将字符写入临时buf中
	int err =
		image_string_tmp(imtmp, font, strcode, pfontitem->path, fontcolor, fontmaxsz, fontminsz,
						 maxangle, &left);
	if (err != 0) {
		return -1;
	}

	im = gdImageCreate(IMGCAPTCHA_WIDTH, IMGCAPTCHA_HEIGHT);
	if (!im) {
		return -1;
	}
	//白色背景
	int im_white = gdImageColorResolve(im, 255, 255, 255);
	//设置透明色
	gdImageColorTransparent(im, im_white);


	//用于记录字符串的整体位置，便于加干扰线
	imgcaptcha_str_rect sr;

	sr.lx = 9999;
	sr.by = 9999;
	sr.rx = 0;
	sr.ty = 0;

	int adjusttime = 1;
	int ignoreout = 0;			//是否忽略宽度越界，1为忽略 其他为不忽略

	while (adjusttime >= 0) {
		//将临时buf中的像素映射到验证码图像空间
		err = image_string(im, imtmp, font, strcode, &sr, ignoreout);

		if (0 == err) {
			break;
		} else if (2 == err) {
			if (1 == adjusttime)
				ignoreout = 1;	//忽略越界的情况，继续写字符
			fontmaxsz = (fontmaxsz - fontminsz) / 4 + fontminsz;
			maxangle = rand() % 5 + 5;

			err =
				image_string_tmp(imtmp, font, strcode, pfontitem->path, fontcolor, fontmaxsz,
								 fontminsz, maxangle, &left);
			if (err != 0) {
				return -1;
			}
		} else if (3 == err) {
			if (1 == adjusttime)
				ignoreout = 1;	//忽略越界的情况，继续写字符
			fontminsz = (fontmaxsz - fontminsz) / 2 + fontminsz;

			err =
				image_string_tmp(imtmp, font, strcode, pfontitem->path, fontcolor, fontmaxsz,
								 fontminsz, maxangle, &left);
			if (err != 0) {
				return -1;
			}
		} else {

		}
		adjusttime--;

	}


	//图像变形
	if (g_imgcaptcha_cfg_data.enable_lens) {
		lens_image(im, imtmp);
	}
	//画干扰线
	if (g_imgcaptcha_cfg_data.enable_curve) {
		imgcaptcha_line_point point[4];

		for (i = 0; i < 1; i++) {
			int pos = get_curve_loc(sr, left, strcode);
			get_bezier_point(point, sr, pos);

			draw_deCasteljau(im, point, 4, degree);
		}
	}
	//加上背景
	if (g_imgcaptcha_cfg_data.bgimg) {
		imbg = gdImageCreate(IMGCAPTCHA_WIDTH, IMGCAPTCHA_HEIGHT);
		if (!imbg) {
			return -1;
		}
		gdImageCopy(imbg, pmemimg, 0, 0, 0, 0, IMGCAPTCHA_WIDTH, IMGCAPTCHA_HEIGHT);
		gdImageCopy(imbg, im, 0, 0, 0, 0, IMGCAPTCHA_WIDTH, IMGCAPTCHA_HEIGHT);
	}

	int dsize;
	void *pmemdata = NULL;
	if (g_imgcaptcha_cfg_data.bgimg) {
		pmemdata = gdImageJpegPtr(imbg, &dsize, -1);
	} else {
		pmemdata = gdImageJpegPtr(im, &dsize, -1);
	}


	if (!pmemdata) {
		gdImageDestroy(imtmp);
		gdImageDestroy(im);
		if (g_imgcaptcha_cfg_data.bgimg) {
			gdImageDestroy(imbg);
		}
		return -1;
	}

	if (dsize <= bufsize) {
		memcpy(pimgdata_buf, pmemdata, dsize);
	} else {
		//产生的图片太大了..
		dsize = -1;
	}

	gdFree(pmemdata);
	gdImageDestroy(imtmp);
	gdImageDestroy(im);

	if (g_imgcaptcha_cfg_data.bgimg) {
		gdImageDestroy(imbg);
	}

	return dsize;

}

static void checkpoint(imgcaptcha_line_point * point)
{
	if (point->x < 2)
		point->x = 2;
	if (point->x > IMGCAPTCHA_WIDTH - 2)
		point->x = IMGCAPTCHA_WIDTH - 2;

	if (point->y < 2)
		point->y = 2;
	if (point->y > IMGCAPTCHA_HEIGHT - 2)
		point->y = IMGCAPTCHA_HEIGHT - 2;
}

/**     
 * @brief  获得干扰线的大概方位，分为6个主要方位，字符区域的：TOP BOTTOM TOP_LEFT TOP_RIGHT BOTTOM_LEFT BOTTOM_RIGHT
 *         当字符不适合干扰线贯穿时，则干扰线位于TOP或BOTTOM位置，如果适合贯穿时，优先选择字符大小大的一边
 * @param[in]   rect: 4个字符的区域
 *              left：描述哪边的字符size大，left==1 则左边字符size大，否则为右边字符size大
 *              buf[4]: 4个字符
 *
 * @return  返回字符的方位 1-6
 */
static int
get_curve_loc(imgcaptcha_str_rect rect, int left, const char buf[4])
{
	int mark[4] = { 0, 0, 0, 0 };
	int i = 0;
	for (i = 0; i < 4; i++) {
		//确定各个字符是否适合贯穿
		mark[i] =
			char_in_str(g_imgcaptcha_cfg_data.curve_badcase_list, strlen(g_imgcaptcha_cfg_data.curve_badcase_list), buf[i]);
	}

	int top = 0;
	if (rect.by < IMGCAPTCHA_HEIGHT - rect.ty) {
		top = 1;
	}

	if ((mark[0] || mark[1]) && (mark[2] || mark[3])) {
		return top ? TOP : BOTTOM;
	}

	if (left > 0) {
		if (mark[0] || mark[1])	//frist or second char in badcase
		{
			return top ? TOP_RIGHT : BOTTOM_RIGHT;
		} else {
			return top ? TOP_LEFT : BOTTOM_LEFT;
		}

	} else {
		if (mark[2] || mark[3])	//third or fourth char in badcase
		{
			return top ? TOP_LEFT : BOTTOM_LEFT;
		} else {
			return top ? TOP_RIGHT : BOTTOM_RIGHT;
		}
	}

	return TOP_RIGHT;
}



/**     
 * @brief   根据方位，获得bezier曲线的4个控制点
 *
 * @param[out]   point[4]: 存取bezier的4个控制点信息 point[0] 和 point[3]为端点， 其他为中间控制点
 * @param[in]    sr：字符区域的信息
 *               pos: 干扰线的大致位置：TOP BOTTOM ...
 *
 * @return  always return NULL
 */
static void
get_bezier_point(imgcaptcha_line_point point[4], imgcaptcha_str_rect sr, int pos)
{
	int temp = 1;

	if (TOP == pos || BOTTOM == pos) {
		temp = (sr.rx - sr.lx) / 2;

		if (temp <= 0)
			temp = 1;
		point[0].x = sr.lx - 5 + rand() % temp;

		temp = 2 * (sr.rx - point[0].x) / 3;
		if (temp <= 0)
			temp = 1;

		point[3].x = point[0].x + (sr.rx - sr.lx) / 3 + rand() % temp;

		temp = rand() % 10 - 5;

		if (TOP == pos) {
			point[0].y = sr.ty + temp;
			point[3].y = sr.ty - temp;
		} else {
			point[0].y = sr.by + temp;
			point[3].y = sr.by - temp;

		}
	}


	if (TOP_LEFT == pos || BOTTOM_LEFT == pos) {

		temp = sr.lx - 5;
		if (temp <= 0)
			temp = 1;

		point[0].x = rand() % temp + 5;

		temp = (sr.rx - sr.lx) / 2;
		if (temp <= 0)
			temp = 1;

		point[3].x = sr.lx + temp / 2 + rand() % temp;
		if (point[3].x - point[0].x < 10)
			point[3].x = point[0].x + 10;

		if (TOP_LEFT == pos) {
			temp = (sr.ty - sr.by) / 2 + 5;
			if (temp <= 0)
				temp = 1;
			point[0].y = sr.ty - rand() % temp;

			temp = (IMGCAPTCHA_HEIGHT - 5 - sr.ty);
			if (temp <= 0)
				temp = 1;

			point[3].y = sr.ty + rand() % temp;
		}
		if (BOTTOM_LEFT == pos) {
			temp = (sr.ty - sr.by) / 2 + 5;
			if (temp <= 0)
				temp = 1;
			point[0].y = sr.by + rand() % temp;

			temp = sr.by - 5;
			if (temp <= 0)
				temp = 1;

			point[3].y = sr.by - rand() % temp;
		}

	}


	if (TOP_RIGHT == pos || BOTTOM_RIGHT == pos) {

		temp = IMGCAPTCHA_WIDTH - sr.rx - 5;
		if (temp <= 0)
			temp = 1;
		point[3].x = sr.rx + rand() % temp;

		temp = (sr.rx - sr.lx) / 2;
		if (temp <= 0)
			temp = 1;

		point[0].x = sr.lx + (sr.rx - sr.lx) / 4 + rand() % temp;
		if (point[3].x - point[0].x < 10)
			point[0].x = point[3].x - 10;

		if (TOP_RIGHT == pos) {
			temp = (sr.ty - sr.by) / 2 + 5;
			if (temp <= 0)
				temp = 1;
			point[3].y = sr.ty - rand() % temp;

			temp = (IMGCAPTCHA_HEIGHT - 5 - sr.ty);
			if (temp <= 0)
				temp = 1;

			point[0].y = sr.ty + rand() % temp;
		}
		if (BOTTOM_RIGHT == pos) {
			temp = (sr.ty - sr.by) / 2 + 5;
			if (temp <= 0)
				temp = 1;
			point[3].y = sr.by + rand() % temp;

			temp = sr.by - 5;
			if (temp <= 0)
				temp = 1;

			point[0].y = sr.by - rand() % temp;
		}

	}
	checkpoint(&(point[0]));
	checkpoint(&(point[3]));

	int lenx = abs(point[3].x - point[0].x);
	int minx = point[3].x > point[0].x ? point[0].x : point[3].x;

	int leny = abs(point[3].y - point[0].y);
	int miny = point[3].y > point[0].y ? point[0].y : point[3].y;

	if (lenx <= 0)
		lenx = 2;
	if (leny <= 0)
		leny = 2;

	temp = 3 * lenx / 5;
	if (temp <= 0)
		temp = 2;

	int curve_level = g_imgcaptcha_cfg_data.curve_level * 2;

	if (curve_level <= 0)
		curve_level = 20;

	point[1].x = minx + lenx / 5 + rand() % temp;
	point[1].y = miny + rand() % leny + rand() % curve_level - curve_level / 2;

	checkpoint(&(point[1]));

	point[2].x = minx + lenx * 4 / 5 - rand() % temp;
	point[2].y = miny + rand() % leny + rand() % curve_level - curve_level / 2;

	checkpoint(&(point[2]));

}

/**     
 * @brief  将字符写入临时图像空间 
 *
 * @param[in]    imtmp: 临时图像空间指针
 *               font[4]: 用于记录4个字符在临时空间的位置信息
 *               fontpath: 字符ttf文件的path
 *               strbuf：目标字符
 *               color：字符颜色
 *               fontmaxsize：字符的最大size
 *               fontminszie：字符的最小size
 *               maxangle：字符可以旋转的最大角度
 * @param[out]   left: 如果左边字符大则left为1 否则为 -1 
 *
 * @return  -1 means failed
 *          0  means success
 */
static int
image_string_tmp(gdImagePtr imtmp, imgcaptcha_font_attr font[4], const char strbuf[4], char *fontpath,
				 int color, const int fontmaxsz, const int fontminsz, int maxangle, int *left)
{

	if (NULL == strbuf) {
		return -1;
	}
	if (NULL == fontpath) {
		return -1;
	}
	if (fontmaxsz < fontminsz || fontminsz < 0) {
		return -1;
	}

	int brect[8];
	int x, y;
	char *err = NULL;

	double fontsz = fontminsz;	//字符开始大小
	double angle = 0;			//字符的旋转角度
	int i, m, n;

	int fontwid, fonthei;

	char str[2];
	str[1] = '\0';

	int szdir = 1;				//字符的大小的递增趋势 1为递增  -1 为递减

	for (i = 0; i < 4; i++) {

		//初始化字符的大小,后续字符遵循递增或者递减的规律
		if (i == 0) {
			fontsz = rand() % (fontmaxsz - fontminsz + 1) + fontminsz;

			if (fontsz - fontminsz > (fontmaxsz - fontminsz) / 2) {
				szdir = -1;
			}

			*left = -szdir;
		} else {

			int szlen = 1;
			if (szdir < 0) {
				szlen = (int) (fontsz - fontminsz);
			} else {
				szlen = (int) (fontmaxsz - fontsz);
			}
			if (szlen <= 0)
				szlen = 1;
			fontsz = fontsz + szdir * (rand() % abs(szlen / (4 - i) + 1));
		}


		str[0] = strbuf[i];

		//确定旋转角度
		if (maxangle <= 0) {
			angle = 0;
		} else {
			angle = (rand() % maxangle - maxangle / 2.) / 180.0 * PI;
		}

		//如果字符size > 27 并且处于容易超出界限的字符集中则限制它的大小
		if (fontsz >= g_imgcaptcha_cfg_data.char_max_scale_size - 3
			&& char_in_str(IMGCAPTCHA_SIZE_BADCASE_LIST, sizeof(IMGCAPTCHA_SIZE_BADCASE_LIST), str[0])) {
			fontsz = g_imgcaptcha_cfg_data.char_max_scale_size - 3;
			if (maxangle <= 4) {
				angle = 0;
			} else {
				angle = (rand() % (maxangle / 2) - maxangle / 4.) / 180.0 * PI;
			}

		}



		int singlechlen = imtmp->sx / 4;	//单个字符在临时图片区域所占的宽度
		int adjusttime = 2;

		int x2 = 0;
		int y2 = 0;
		int mark = 0;

		while (adjusttime > 0) {
			for (m = 0; m < imtmp->sy; m++) {
				//将临时图片区中的对应某个字符的位置区域清空  
				memset(imtmp->pixels[m] + i * singlechlen, 0,
					   singlechlen * sizeof(imtmp->pixels[0][0]));
			}

			//将字符写在临时图片区域的中间位置
			err =
				gdImageStringFT(imtmp, &brect[0], color, fontpath, fontsz, angle,
								(imtmp->sx / 4) / 3 + i * (imtmp->sx / 4), imtmp->sy / 3 * 2, str);

			if (err) {
				return -1;
			}
			//获得该字符的位置
			get_font_wh(brect, &fontwid, &fonthei);

			y = brect[5] > brect[7] ? brect[7] : brect[5];
			x = brect[0] < brect[6] ? brect[0] : brect[6];

			if (y < 0)
				y = 0;
			if (x < 0)
				x = 0;

			y2 = y + fonthei < imtmp->sy ? y + fonthei : imtmp->sy;
			x2 = x + fontwid < imtmp->sx ? x + fontwid : imtmp->sx;

			//获取文字有效像素的最低y坐标
			for (n = y; n < y2; n++) {
				mark = 0;
				for (m = x; m < x2; m++) {
					if (imtmp->pixels[n][m] != 0) {
						mark = 1;
						y = n;
						break;
					}

				}
				if (mark == 1) {
					break;
				}
			}

			//获取文字的高度
			for (n = y2 - 1; n > y && n > 0; n--) {
				mark = 0;
				for (m = x; m < x2; m++) {
					if (imtmp->pixels[n][m] != 0) {
						mark = 1;
						fonthei = n - y + 1;
						break;
					}

				}
				if (mark == 1) {
					break;
				}
			}


			if (fonthei > IMGCAPTCHA_CHAR_MAX_HEIGHT)	//调整高度
			{

				fontsz -= 5;
				if (fontsz < fontminsz)
					fontsz = fontminsz;
				angle = (rand() % 10 - 5.0) / 180.0 * PI;
			}

			if (fonthei < IMGCAPTCHA_OVERLAP_CHAR_MIN_HEIGHT)	//调整高度
			{
				fontsz += 5;
				if (fontsz > fontmaxsz)
					fontsz = fontmaxsz;
				angle = (rand() % 10 - 5.0) / 180.0 * PI;
			}

			if (fontwid < IMGCAPTCHA_OVERLAP_CHAR_MIN_WIDTH && fonthei >= IMGCAPTCHA_OVERLAP_CHAR_MIN_HEIGHT 
					&& fonthei <= IMGCAPTCHA_CHAR_MAX_HEIGHT)	//调整宽度
			{
				fontsz += 5;
				if (fontsz > fontmaxsz)
					fontsz = fontmaxsz;
				angle = (rand() % 10 + 5.0) / 180.0 * PI;
			}

			if ((fonthei < IMGCAPTCHA_HEIGHT && fonthei >= IMGCAPTCHA_OVERLAP_CHAR_MIN_HEIGHT
				 && fontwid >= IMGCAPTCHA_CHAR_MIN_WIDTH) || adjusttime == 0) {
				break;
			}

			adjusttime--;
		}

		//记录字符的位置信息
		font[i].locy = y > 0 ? y : 1;
		font[i].locx = x > 0 ? x : 1;
		font[i].wid = fontwid;
		font[i].hei = fonthei;
		font[i].sz = fontsz;
		font[i].angle = angle;

	}

	return 0;
}

/**     
 * @brief   获得字符的宽度和高度
 *
 */
static int
get_font_wh(int brect[8], int *wid, int *hei)
{
	int x = brect[2] - brect[6];
	int y = brect[3] - brect[7];

	int x2 = brect[4] - brect[0];
	int y2 = brect[1] - brect[5];

	*wid = x > x2 ? x : x2;
	*hei = y > y2 ? y : y2;
	return 0;
}

/**     
 * @brief  判断字符组合是否在重叠的badcaselist中
 *
 * @param  ch：   当前字符
 *         next： 紧跟其后的字符
 *
 * @如果在badcaselist的组合中则返回true，否则为false 
 *
 */
static int
in_badcaselist(char ch, char nextch)
{
	unsigned int i, j;
	for (i = 0; i < strlen(g_imgcaptcha_cfg_data.overlap_badcase_list) - 1; i++) {
		if (ch == g_imgcaptcha_cfg_data.overlap_badcase_list[i] && ':' == g_imgcaptcha_cfg_data.overlap_badcase_list[i + 1]) {
			for (j = i + 1;
				 j < strlen(g_imgcaptcha_cfg_data.overlap_badcase_list)
				 && g_imgcaptcha_cfg_data.overlap_badcase_list[j] != ' '; j++) {
				if (g_imgcaptcha_cfg_data.overlap_badcase_list[j] == nextch)
					return 1;
			}
			return 0;

		}

	}
	return 0;
}

/*
 * @brief 将临时图像空间中的字符复制到验证码图像空间中，如果字符宽度超出字符空间的限制，则返回重新在临时空间中绘制，
 *        如果忽略这种异常则强制复制在验证码图像空间内的字符像素，超出部分丢弃
 *
 * @param[in] im               验证码图像空间指针
 *            imtmp            临时图像空间指针
 *            font[4]          临时空间总的字符位置
 *            strbuf           4个字符
 *            ignoreout        是否忽略字符宽度超出im图像空间的情况  1 为忽略，其他为不忽略
 *
 * @param[out] sr              字符区域的空间位置
 *
 * @return  成功返回 0 如果宽度出现异常且不忽略则返回 2 或者 3 
 *
 */
static int
image_string(gdImagePtr im, gdImagePtr imtmp, imgcaptcha_font_attr font[4], const char *strbuf, imgcaptcha_str_rect *sr,
			 int ignoreout)
{

	int startx = 2;
	int starty = 0;

	int i, j, k;
	int m, n;

	int premax = -1, nextmax = -1;

	char str[2];
	str[1] = '\0';

	//用与记录字符有效像素离字符边界的距离
	int left[4] = { 0 };
	int right[4] = { 0 };

	//字符与字符之间的空白距离
	int suox[4] = { 0 };

	imgcaptcha_font_attr newfont[4];

	int len[IMGCAPTCHA_HEIGHT] = { 0 };

	//两个字符之间的最短距离
	int minlen = 9999;
	int sumwid = IMGCAPTCHA_STR_CODE_MAX_WIDTH;

	//重叠像素的数目
	int minnum = 0;

	//重叠像素的垂直高度
	int maxverlen = 0;
	int lowloc = -1;

	double overlaprate = g_imgcaptcha_cfg_data.overlap_rate / 100.0;
	double heightoverlaprate = g_imgcaptcha_cfg_data.height_overlap_rate / 100.0;


	sr->lx = 0;
	sr->rx = IMGCAPTCHA_WIDTH;
	sr->ty = 0;
	sr->by = 9999;

	for (i = 0; i < 4; i++) {
		minlen = 9999;
		newfont[i].locx = font[i].locx;
		newfont[i].locy = font[i].locy;
		newfont[i].wid = font[i].wid;
		newfont[i].hei = font[i].hei;

		//确定每个字符垂直方向的位置
		starty = 0;
		if (IMGCAPTCHA_HEIGHT - font[i].hei - 4 > 0) {
			starty = (IMGCAPTCHA_HEIGHT - font[i].hei) / 4 + rand() % ((IMGCAPTCHA_HEIGHT - font[i].hei) / 2);
			if (font[i].locy - starty >= 0) {
				newfont[i].locy -= starty;
			}
		} else {
			starty = (IMGCAPTCHA_HEIGHT - font[i].hei) / 2;
			if (starty < 0)
				starty = 0;
		}

		if (sr->by > starty)
			sr->by = starty;
		if (sr->ty < starty + font[i].hei)
			sr->ty = starty + font[i].hei;

		if (font[i].locy + IMGCAPTCHA_HEIGHT < imtmp->sy) {
			newfont[i].hei = IMGCAPTCHA_HEIGHT;
		}
		//第一个字符左边有效像素离字符边界的距离,且第一个字符不需要粘连
		if (i == 0) {
			int mark = 0;

			for (m = newfont[i].locx; m < newfont[i].locx + newfont[i].wid && m < imtmp->sx; m++) {
				mark = 0;

				for (n = newfont[i].locy; n < newfont[i].locy + newfont[i].hei && n < imtmp->sy;
					 n++) {

					if (imtmp->pixels[n][m] != 0) {
						mark = 1;
						break;
					}
				}
				if (mark != 0)
					break;
				left[i]++;
			}
			sumwid = sumwid - newfont[i].wid + left[i];
			continue;
		}

		premax = -1;
		nextmax = -1;
		//计算两个字符之间的距离

		minlen = 9999;
		for (j = 0; j < IMGCAPTCHA_HEIGHT; j++) {

			premax = -1;
			for (k = newfont[i - 1].locx + newfont[i - 1].wid;
				 k < imtmp->sx && k > newfont[i - 1].locx; k--) {
				if (j < newfont[i - 1].hei && imtmp->pixels[newfont[i - 1].locy + j][k] != 0) {
					premax = newfont[i - 1].locx + newfont[i - 1].wid - k;
					break;
				}
			}

			nextmax = -1;

			for (k = newfont[i].locx; k < imtmp->sx && k < newfont[i].locx + newfont[i].wid; k++) {
				if (j < newfont[i].hei && imtmp->pixels[newfont[i].locy + j][k] != 0) {
					nextmax = k - newfont[i].locx;
					break;
				}
			}

			if (premax != -1 && nextmax != -1) {
				len[j] = nextmax + premax;
				if (len[j] < minlen) {
					right[i - 1] = premax;
					left[i] = nextmax;
					minlen = len[j];
				}
			} else {
				len[j] = 9999;
			}

		}



		minnum = 0;
		maxverlen = 0;
		lowloc = -1;

		//如果字符之间没有水平可以平移相交的字符则不进行重叠
		if (minlen == 9999 || in_badcaselist(strbuf[i - 1], strbuf[i])) {
			suox[i] = -2;
		} else {
			//计算字符重叠的程度
			for (j = 0; j < IMGCAPTCHA_HEIGHT; j++) {
				if ((len[j] - minlen) < g_imgcaptcha_cfg_data.overlap_pixel_num + 1) {
					if (lowloc == -1) {
						lowloc = j;
					} else {
						maxverlen = j - lowloc;
					}
					minnum++;
				}
			}


			//如果字符重叠程度超过字符本身高度一半，则不只靠近，否则重叠
			if ((minnum < font[i].hei * overlaprate && minnum < font[i - 1].hei * overlaprate)
				&& (maxverlen < (font[i].hei * heightoverlaprate)
					&& maxverlen < (font[i - 1].hei * heightoverlaprate))) {
				suox[i] = g_imgcaptcha_cfg_data.overlap_pixel_num;
			} else {
				suox[i] = -2;
			}
		}

		//计算剩余的图像水平宽度
		sumwid = sumwid - newfont[i].wid + (right[i - 1] + left[i] + suox[i]);

		if (sumwid < 0) {
			//如果不忽略这种异常情况，则直接返回2
			if (ignoreout != 1)
				return 2;

		}



	}

	//如果整体字符长度过窄，进行调整
	if (sumwid >= IMGCAPTCHA_WIDTH - IMGCAPTCHA_STR_CODE_MIN_WIDTH) {

		//如果不忽略这种异常情况，则直接返回3
		if (ignoreout != 1)
			return 3;


	}

	int tmpx = 0;
	int tmpy = 0;

	//确定字符开始的水平位置
	if (sumwid - 6 > 0) {
//      startx = rand()% (sumwid / 3 ) +  sumwid / 3;
		startx = sumwid / 3;
	} else {
		startx = 3;
	}

	sr->lx = startx + left[0];

	//copy 临时图像空间的图像调色板信息
	im->colorsTotal = imtmp->colorsTotal;
	for (i = 0; i < imtmp->colorsTotal; i++) {
		im->open[i] = imtmp->open[i];
		im->alpha[i] = imtmp->alpha[i];
		im->red[i] = imtmp->red[i];
		im->blue[i] = imtmp->blue[i];
		im->green[i] = imtmp->green[i];
	}


	for (i = 0; i < 4; i++) {
		if (i == 0) {
			startx = startx - left[i];
		} else {
			startx = startx - right[i - 1] - suox[i] - left[i];
		}


		for (n = newfont[i].locy; n < newfont[i].locy + newfont[i].hei && n < imtmp->sy; n++) {

			for (m = newfont[i].locx; m < newfont[i].locx + newfont[i].wid && m < imtmp->sx; m++) {
				tmpy = n - newfont[i].locy;
				tmpx = startx + m - newfont[i].locx;
				if (imtmp->pixels[n][m] != 0 && tmpy >= 0 && tmpy < IMGCAPTCHA_HEIGHT
					&& tmpx >= 0 && tmpx < IMGCAPTCHA_WIDTH) {
					if (im->pixels[tmpy][tmpx] != 0 &&
						gdImageRed(im, im->pixels[tmpy][tmpx]) < gdImageRed(imtmp,
																			imtmp->pixels[n][m])) {
						continue;
					}
					im->pixels[tmpy][tmpx] = imtmp->pixels[n][m];

				}

			}
		}
		startx = startx + newfont[i].wid;

	}

	sr->rx = startx;


	return 0;
}

/*
 * @brief  鱼眼变形算法，算法的思想是根据字符距离中心点位置的远近采用相同的缩放比例缩放字符
 *         从而造成字符越靠近边界字符变形越明显的效果
 *
 */

static void
lens_image(gdImagePtr im, gdImagePtr imtmp)
{
	int nx, ny;
	int i, j, i2, j2;
	double x, y, x2, y2, r;
	int nxout, nyout;
	nx = IMGCAPTCHA_WIDTH;
	ny = IMGCAPTCHA_HEIGHT;
	nxout = nx;
	nyout = ny;

	int tmp = g_imgcaptcha_cfg_data.lens_deformation_level / 2;

	if (tmp <= 0)
		tmp = 1;

	tmp = rand() % tmp + tmp;

	double alphax = tmp / 100.0;
	double alphay = alphax * IMGCAPTCHA_HEIGHT / IMGCAPTCHA_WIDTH;

	for (i = 0; i < IMGCAPTCHA_HEIGHT; i++) {
		for (j = 0; j < IMGCAPTCHA_WIDTH; j++) {
			imtmp->pixels[i][j] = im->pixels[i][j];
			im->pixels[i][j] = 0;
		}
	}

	for (i = 0; i < nxout; i++) {
		for (j = 0; j < nyout; j++) {
			x = (2 * i - nxout) / (double) nxout;
			y = (2 * j - nyout) / (double) nyout;
			r = x * x + y * y;
			x2 = x / (1 + alphax * r);
			y2 = y / (1 + alphay * r);
			i2 = (int) ((x2 + 1) * nx / 2);
			j2 = (int) ((y2 + 1) * ny / 2);
			if (i2 >= 0 && i2 < nx && j2 >= 0 && j2 < ny && imtmp->pixels[j2][i2] > 0) {
				im->pixels[j][i] = imtmp->pixels[j2][i2];
			}
		}
	}
}

/*
 * @brief  绘制bezier曲线，采用deCasetljau算法
 *
 * @param[in] im图像空间指针
 *            point控制点位置
 *            len 控制点的格式
 *            color干扰线的颜色
 *
 * @return    NULL
 *
 */
static void
draw_deCasteljau(gdImagePtr im, imgcaptcha_line_point * point, int len, int color)
{

	if (len != IMGCAPTCHA_BEZIER_POINT_NUM) {
		return;
	}

	float pflx[IMGCAPTCHA_BEZIER_POINT_NUM];
	float pfly[IMGCAPTCHA_BEZIER_POINT_NUM];
	float fltempx, fltempy, flu;	//flu-------u2?êy 
	int i, n, j;

	int linewid[8] = { 1, 1, 2, 2, 2, 2, 3, 3 };

	n = len;

	fltempx = point[0].x;
	fltempy = point[0].y;

	int linecolor = 0;
	int degree = 0;

	for (i = 0; i < n; i++) {
		pflx[i] = point[i].x;
		pfly[i] = point[i].y;
	}

	for (flu = 0; flu <= 1; flu += 0.1 / n) {
		for (i = 1; i < n; i++) {
			for (j = 0; j < n - i; j++) {
				pflx[j] = (1 - flu) * pflx[j] + flu * pflx[j + 1];
				pfly[j] = (1 - flu) * pfly[j] + flu * pfly[j + 1];
			}
		}

		if (((int) fltempx) >= 0 && ((int) fltempx) < im->sx && ((int) fltempy) >= 0
			&& ((int) fltempy) < im->sy && ((int) pflx[0]) >= 0 && ((int) pflx[0]) < im->sx
			&& ((int) pfly[0]) >= 0 && ((int) pfly[0]) < im->sy) {
			gdImageSetThickness(im, linewid[rand() % 8]);
			degree = color + (rand() % 9) * 5;
			linecolor = gdImageColorResolve(im, degree, degree, degree);

			//gdImageLine 中对边界已经做判断
			gdImageLine(im, (int) fltempx, (int) fltempy, (int) pflx[0], (int) pfly[0], linecolor);
		}
		fltempx = pflx[0];
		fltempy = pfly[0];
	}

}
int
captcha_gen(int captcha_type, const char *strcode, int code_len, char *pdata_buf, const int buf_size)
{
	if (NULL == strcode || code_len <= 0 || NULL == pdata_buf || buf_size <= 0) {
		return -1;
	}
	int size = 0;
	
	switch (captcha_type) {
	case IMGCAPTCHA_IMAGE_CAPTCHA:
		size = overlap_grayimg_gen(strcode, code_len, pdata_buf, buf_size);
		if (size <= 0) {
			return -1;
		}
		
		break;
	default:
		return -1;
	}
	return size;
}
