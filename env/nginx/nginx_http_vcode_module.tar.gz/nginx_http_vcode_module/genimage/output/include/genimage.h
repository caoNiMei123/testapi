/*
 * genimage.h
 *
 * Developed by UNKNOWN AUTHOR <UNKNOWN@undefined.net>
 * Copyright (c) 2008 UNKNOWN Company
 * Licensed under terms of GNU General Public License.
 * All rights reserved.
 *
 * Changelog:
 * 2008-04-23 - created
 *
 */

/* $Platon$ */

#ifndef GENIMAGE_H
#  define GENIMAGE_H


#endif /* #ifndef GENIMAGE_H */

/***************************************************************************
 * 
 * Copyright (c) 2008 Baidu.com, Inc. All Rights Reserved
 * $Id: genimage.h,v 1.6 2008/06/30 12:56:13 wenlf Exp $ 
 * 
 **************************************************************************/
/**
 * @file genimage.h
 * @author wenlf(com@baidu.com)
 * @date 2008/04/23 20:43:47
 * @version $Revision: 1.6 $ 
 * @brief 
 *  
 **/

#ifndef  __GENIMAGE_H_
#define  __GENIMAGE_H_

#define IMGCAPTCHA_MIN_IMAGE_BUF_SIZE   (1024*10)
#define IMGCAPTCHA_IMAGE_CAPTCHA 0		  /**< 图片验证码  */
#define IMGCAPTCHA_AUDIO_CAPTCHA 1		  /**< 语音验证码  */

#define IMGCAPTCHA_FONT_MAXNUM 100		  /**< 字体文件的最大数目       */
#define IMGCAPTCHA_PIC_MAXNUM 100		  /**< 背景文字的最大数目       */

#define IMGCAPTCHA_NORMAL_FONT  0x01		  /**< 正常字体       */
#define IMGCAPTCHA_SPECIAL_FONT 0x02		  /**< 特殊字体       */
#define IMGCAPTCHA_MANUAL_FONT  0x04		  /**< 手写体       */

#define IMGCAPTCHA_SET_DEFAULT    0x00		  /**< 默认样式,无背景、干扰线、变形  */
#define IMGCAPTCHA_SET_BG    0x01		  /**< 设置背景       */
#define IMGCAPTCHA_SET_CURVE 0x02		  /**< 增加干扰线     */
#define IMGCAPTCHA_SET_LEN   0x04		  /**< 设置变形   */

#define IMGCAPTCHA_MAX_PATH_LEN    512
#define IMGCAPTCHA_PREFIX_FN_MAX_LEN    32

typedef struct _imgcaptcha_cfg_data_t {
    int width;
    int height;
    char font_path[IMGCAPTCHA_MAX_PATH_LEN];
    int enable_fm;              //是否采用manualscript fonts
    int enable_fs;              //specail fonts
    int enable_fn;              //normal fonts

    int bgimg;                  //使用背景图

    int lens_deformation_level;
    char curve_badcase_list[100];
    char overlap_badcase_list[1024];
    int enable_lens;            //是否采用变形
    int enable_curve;           //使用干扰线
    int curve_level;            //干扰线起伏程度
    int char_max_scale_size;    //gd库写字符时的最大size
    int max_angle;              //最大的旋转角度
    int overlap_pixel_num;      //水平重合像素的个数    1-4 推荐2或者3
    int overlap_rate;           //重合程度  0-100 0不重合 100 完全重合
    int height_overlap_rate;    //重合点之间的高度控制  0-100 0不重合 100 完全重合 避免出现H3 这种字符粘接
} imgcaptcha_cfg_data_t;


/**
 * @brief 初始化验证码的各种参数
 *
 * @param [in] sample_path :      指定字体文件和背景文件的目录
 * @param [in] width   :          验证码图片的宽度,目前只支持120
 * @param [in] height   :         验证码图片的长度,目前只支持40
 * @param [in] sample_size   :    验证码图片字体大小,0表示使用默认值,如果需要调整长宽值，则可能需要调整该值,否则不需要
 * @param [in] sample_type   :    字体类型,见宏定义, 可以组合,比如需要正常字体和特殊字体：
 *                                IMGCAPTCHA_NORMAL_FONT | IMGCAPTCHA_SPECIAL_FONT
 * @param [in] captcha_type   :   验证码图片的风格 见宏定义,组合方式如：IMGCAPTCHA_SET_BG | IMGCAPTCHA_SET_CURVE
 * @param [in] reserved   :  保留字段
 * @return  int 失败返回 -1 成功返回 0
 * @retval   
 * @see 
 * @note 
 * @author wenlf
 * @date 2008/04/23 22:13:23
**/
int genimage_init(const char *sample_path, int width , int height, int sample_size ,  unsigned int sample_type , unsigned int captcha_stlye);
/**
 * @brief 生成验证码图片的主函数，传入4个字符，传出验证码图片的buf，目前仅支持4个字符，宽度120 长度40的验证码图片
 * 后续会有改进
 *
 * @param [in] captcha_type   :      产生验证码的类型,见宏定义 IMAGE_CAPTCHA IMAGE_CAPTCHA,目前只支持图片验证码
 * @param [in] strcode   :           传入的4个字符
 * @param [in] code_len   :          strcode的长度 目前只支持4个
 * @param [in/out] pdata_buf   :     存放验证码数据的buf,内存需要事先分配好 
 * @param [in] buf_size  :           pdata_buf的长度,120*40的图片推荐使用 MIN_IMAGE_BUF_SIZE
 * @param [out] data_size            返回验证码数据的长度，即pdata_buf中有效数据的长度,只有返回值为0时可信 
 * @return  int 失败返回-1， 成功返回0
 * @retval   
 * @see 
 * @note 
 * @author wenlf
 * @date 2008/04/23 22:17:39
**/
int captcha_gen(int captcha_type, const char *strcode, int code_len, char *pdata_buf, const int buf_size);

#endif //__GENIMAGE_H_
