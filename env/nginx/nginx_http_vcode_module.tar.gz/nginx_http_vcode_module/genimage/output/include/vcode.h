/** $Id: vcode.h,v 1.17 2008/10/22 03:25:18 fengyong Exp $ */
/**
 *  vcode用于生成验证码加密串和反解加密串
 *  特性：
 *  1.vcode的生成算法要尽可能随机和均匀，保证长时间内不生成重复的vcode
 *  2.vcode的加密解密算法的种子定时切换
 *  3.vcode支持超时监测 完整性检测 支持内置app_key检测	
 *
 *
 **/
#ifndef __VCODE_HEAD_FILE__
#define __VCODE_HEAD_FILE__
#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 初始化vcode加密解密算法
 * @param k 随机值KEY
 * @param charset 验证码字符集
 * @param charlen 验证码图片中字符长度通常为4
 * @param changehour 种子切换时间
 * @return a void 
 * @author fengy
 * @date Mon Apr 21 16:12:53 CST 2008
 * @version 1.0.0 
 * @todo 
**/
int vcode_init(long k,char *charset,int charlen,int changehour);

/**
 * @brief 生成加密串vcode
 *
 * @param vcodebuf 
 * @param bufsize = sizeof(vcodebuf)
 * @param app_key 应用需要而传入的一个串, 默认为NULL, NULL 和 空串("") 等价
 * @return a void 
 * @author fengy
 * @date Mon Apr 21 15:59:51 CST 2008
 * @version 1.0.0 
 * @todo 
**/
int vcode_gen(char* vcodebuf, unsigned int bufsize, const char* app_key);

/**
 * @brief 验证vcode与验证码中4个字符rstr是否相符
 *
 * detail description about captcha_verify
 * @param vcode a const char*
 * @param rstr a const char*
 * @param span_secs 在种子切换时间点 正负偏移span_secs区间内，前后种子都有效
 * 				避免种子切换时刻，加密解密算法的种子不一致
 * @return 0 相符 -1 不相符 
 * @author fengy
 * @date Mon Apr 21 16:03:15 CST 2008
 * @version 1.0.0 
 * @todo 
**/
int vcode_verify( const char* vcode, const char *rstr, const unsigned int span_secs );

/**
 * @brief 从加密串vcode中反解出验证码字符
 *
 * @param vcode a const char*
 * @param prstrbuf a char strbuf[5] end with \0 
 * @return -1 出错; 0 正确
 * @author fengy
 * @date Mon Apr 21 16:13:50 CST 2008
 * @version 1.0.0 
 * @todo 
**/
int vcode_getstr( const char* vcode, char *prstrbuf );

/**
 * @brief 校验vcode 完整性/超时/app_key检查 如果app_key为NULL则不进行检查, NULL和空串("")等价
 * @param vcodebuf vcode
 * @param 应用层key,vcode_gen采用的app_key
 * @return -1 完整性或app_key交易不通过 >=0 返回超时时间 秒
 *
**/
int vcode_check(const char *vcodebuf, const char* app_key);

#ifdef __cplusplus
}
#endif

#endif //__VCODE_HEAD_FILE__

