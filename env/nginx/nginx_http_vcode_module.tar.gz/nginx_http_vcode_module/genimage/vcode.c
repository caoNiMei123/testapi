#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>
#include <ctype.h>
#include <openssl/md5.h>
#include "vcode.h"

static int g_init=0;
static unsigned int g_charlen=4;
static int g_changehour=7;
static int g_key=250;
static char* g_string = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
static int g_stringsize = 36;
static int * g_randkey;
static int g_randkeysize;
const unsigned int MAX_APP_KEY_LEN = 33;

int encode_hex(const unsigned char *data, int length, char *buffer, int buflen)
{
	static const char hex[] = "0123456789ABCDEF";
	const unsigned char *p;
	int i;

	if (buflen <=length*2 )
		return -1; 
	for (p = data, i = 0; i < length && (i * 2) < (buflen - 1); p++, i++) {
		buffer[i * 2]       = hex[(*p & 0xf0) >> 4]; 
		buffer[(i * 2) + 1] = hex[(*p & 0x0f)];
	}   
	buffer[length * 2] = '\0';
	return length*2;
}

int decode_hex(const char *data, unsigned char *buffer, int buflen)
{
	const char *p;
	int i;
	unsigned char part;

	int dlen = (int)strlen(data);
	if (buflen <dlen/2 )
		return -1;
	memset(buffer, 0, buflen);

	for (p = data, i = 0; i<dlen; p++, i++) {
		if (data[i] >= '0' && data[i] <= '9')
			part = data[i] - '0';
		else if (data[i] >= 'A' && data[i] <= 'F')
			part = data[i] - 'A' + 10;
		else if (data[i] >= 'a' && data[i] <= 'f')
			part = data[i] - 'a' + 10;
		else
			return -1;
		if (i % 2 == 0)
			part <<= 4;
		buffer[i / 2] |= part;
	}
	if( buflen>dlen/2 )
		buffer[dlen/2] = 0;
	return dlen/2;
}


/**
 * @brief 根据seed, 产生一个随机key串
 *        算法: 
 *        1. 用seed, seed^2 作为初始数, 产生斐波那契数列;
 *        2. 按照规则, 每次从数列中取出一个数, 进行处理, 存放入array中
 *        3. 重复步骤2, array_size次
 * 
 * @param seed 随机因子
 * @param array 需要填放的数组
 * @param array_size array的长度
 * @author wangbo
 * @date Mon Jun 30 17:06:10 CST 2008
 * @version 1.0.0
**/
static void gen_randomkey(int seed, int array[], unsigned int array_size)
{
	if (array == NULL || array_size == 0)
		return;

	const unsigned int MAX = 1024; // MAX 要
	unsigned int i,j;

	// 产生一个斐波那契数列
	int fibonacci[MAX];
	fibonacci[0] = seed > 0 ? seed : 1;
	fibonacci[1] = seed != 0 ? seed * seed : 2;
	for (i=2; i < MAX; i++)
	{
		// 会溢出, 溢出不会影响
		fibonacci[i] = fibonacci[i - 1] + fibonacci[i - 2];
	}

	// 每次从上面产生的数列中,取出一个数,通过变换后,填入到array中
	int base = seed + array_size * array_size;
	for (i=0; i < array_size; i++)
	{
		const unsigned int MD5_SIZE = 16;
		char md5[MD5_SIZE];
		int t_base = base + (array_size - i);
		MD5((const unsigned char*)&t_base, sizeof (t_base), (unsigned char*)md5);
		// 取第(i + array_size) % MAX个元素
		array[i] = fibonacci[(i + array_size) % MAX];
		for (j=0; j < MD5_SIZE; j++)
		{
			array[i] ^= md5[j];
		}
		// 得到有符号int最大值
		unsigned int max_int = (unsigned int)(-1);
		max_int >>= 1;

		// 做无符号处理, 防止负数出现
		array[i] &= max_int;
		//printf("%d\n", array[i]);
	}
}

int vcode_init(long k, char *charset, int charlen, int changehour)
{
	if(!charset || strlen(charset) ==0 || charlen <4 || charlen>9 || changehour <0 || changehour > 24){
		fprintf(stderr,"vcode_init args invalid!\n");
		return -1;
	}
	if(g_init==1){
		fprintf(stderr,"vcode_init already init!\n");
		return -1;
	}

	const int randkey_size = 300;
	g_changehour = changehour;
	g_charlen=charlen;
	struct timeval now;
	gettimeofday(&now, NULL );
	srandom(now.tv_sec);
	g_key = k;
	g_randkeysize = randkey_size;
	g_randkey = (int*)malloc(randkey_size * sizeof (int));//new int[randkey_size];
	if (g_randkey == NULL)
	{
		fprintf(stderr, "malloc g_randkey error\n");
		return -1;
	}
	gen_randomkey(g_key, g_randkey, g_randkeysize);

	char *c = charset;
	while(*c){
		if(!isalnum(*c++)){
			fprintf(stderr,"vcode_init charset args invalid!\n");
	    	return -1;
		}
	}
	g_string = (char*)malloc((strlen(charset) + 1) * sizeof (char));
	if (g_string == NULL)
	{
		fprintf(stderr, "malloc g_string error\n");
		return -1;
	}
	strcpy(g_string, charset);
//	g_string = charset;
	g_stringsize = strlen(charset);
	g_init = 1;
	return 0;
}

int vcode_gen(char *vcodebuf,unsigned int bufsize, const char* app_key)
{
	if(!vcodebuf || bufsize ==0){
		fprintf(stderr,"vcode_gen args invalid!\n");
		return -1;
	}
	if(g_init!=1){
		fprintf(stderr,"vcode not init\n");
		return -1;
	}
	char buf[256];
	unsigned char md[18];
	char md_hex[34];
	long rd;
	struct timeval now;
	rd=random();
	gettimeofday(&now, NULL );
	//printf("gen time %lu\n",now.tv_sec);

	// app_key 处理.
	int app_key_len = 0;
	char app_key_array[MAX_APP_KEY_LEN + 1];
	bzero(app_key_array,MAX_APP_KEY_LEN + 1);
	if (app_key != NULL)
	{
		app_key_len = strlen(app_key);
		if ((unsigned int)app_key_len > MAX_APP_KEY_LEN)
			app_key_len = MAX_APP_KEY_LEN;
		memcpy(app_key_array, app_key, app_key_len);
		app_key_array[app_key_len] = 0;
	}

	snprintf(buf,256,"%02d%s%05d%ld%024ld", app_key_len, app_key_array, g_key,rd,now.tv_sec);
	//snprintf(buf,256,"%05d%ld%016ld",g_key,rd,now.tv_sec);
	//printf("buf [%s]\n",buf);
	//printf("key rand time [%s] len[%d]\n",buf,strlen(buf));
	
	char tmp[512]={0};
	encode_hex((const unsigned char*)buf, strlen(buf),tmp,512);
	
	//printf("gen md5 buf [%s]",tmp);
	MD5((const unsigned char *)tmp,strlen(tmp),md);
	md[16]=0;
	encode_hex((const unsigned char *)md,16,md_hex,34);
	//printf("md5 [%s]\n",md_hex);
	
	snprintf(buf,256, "%02d%s%ld%024ld", app_key_len, app_key_array, rd,(now.tv_sec));
	encode_hex((const unsigned char*)buf, strlen(buf),tmp,512);
	snprintf(vcodebuf,bufsize,"%s%s",tmp,md_hex);
	//encode_hex((const unsigned char*)code, strlen(code), vcodebuf, bufsize);
	
	//printf("vcode [%s] len[%d]\n",vcodebuf,strlen(vcodebuf));
	return 0;
}

int vcode_check(const char *vcodebuf, const char* app_key)
{
	if (vcodebuf == NULL)
		return -1;

	const int CODE_SIZE = 100;
	char code[CODE_SIZE + 1] ;
	bzero(code,CODE_SIZE + 1);
	int ret = decode_hex(vcodebuf, (unsigned char*)code, CODE_SIZE);
	if (ret < 0)
		return -1;
	//printf("decode_hex : %s\n",code);
	int app_key_len = -1;
	if(*code<'0' || *code>'9' || *(code+1)<'0' || *(code+1)>'9')
		return -1;
	if (sscanf(code, "%2d", &app_key_len) != 1 || app_key_len < 0)
		return -1;
	char app_key_array[MAX_APP_KEY_LEN + 1];
	bzero(app_key_array,MAX_APP_KEY_LEN + 1);

	// 检查app_key
	if (app_key == NULL)
	{
		if (app_key_len != 0)
			return -1;

		app_key_array[0] = 0;
	}
	else
	{
		if (app_key_len < 0 || (unsigned int)app_key_len > MAX_APP_KEY_LEN || (unsigned int)app_key_len >= strlen(code))
			return -1;
		unsigned int len = strlen(app_key);
		if (len > MAX_APP_KEY_LEN)
			len = MAX_APP_KEY_LEN;
		if (len != (unsigned int)app_key_len)
			return -1;

		if (strncmp(app_key, code + 2, app_key_len))
			return -1;
		
		strncpy(app_key_array, app_key, app_key_len);
		app_key_array[app_key_len] = 0;

	}
	int offset = app_key_len + 2;
	
	char buf[256];
	unsigned char md[18];
	char time_tmp[26];//md_hex[34];
	int len = strlen(vcodebuf)/2;
	//int len = strlen((char *)code);
	int real_len = len - offset - 16;
	if(real_len <= 0)
		return -1;
	snprintf(buf,256,"%02d%s%05d", app_key_len, app_key_array, g_key);
	int app_key_total_len = 2 + app_key_len;
	strncpy(buf + app_key_total_len + 5,code + offset, real_len);
	buf[app_key_total_len + 5 + real_len]=0;
	//printf("buf [%s]\n",buf);
	char tmp[512]={0};
	encode_hex((const unsigned char *)buf,app_key_total_len+5+real_len,tmp,512);
	//printf("md5 buf [%s]",tmp);
	MD5((const unsigned char *)tmp,strlen(tmp),md);
	md[16]=0;
	//encode_hex(md,16,md_hex,34);

	if(memcmp((void *)(code+len-16),(void *)md,16))
		return -1;
	

	strncpy(time_tmp,(char *)(code+len-40),24);
	time_tmp[24]=0;
	long t = atol(time_tmp);
	struct timeval now;
	gettimeofday(&now, NULL);
	//printf("check time %lu gen time %lu time %s\n",now.tv_sec,t,time_tmp);
	return abs(now.tv_sec - t);
}

int _vcode_getstr(const char *vcodebuf,char *str,const unsigned int daynum)
{
	if(!vcodebuf || !str)
		return -1;
	if(g_init!=1)
		return -1;
	unsigned char md[18];
	char buf[512];
	unsigned int i,j,v;
	snprintf(buf,512,"%d%d%d%s",daynum,g_randkey[daynum%g_randkeysize],g_key,vcodebuf);
	MD5((const unsigned char *)buf,strlen(buf),md);
	unsigned int step = 16/g_charlen;
	for(i=0;i<g_charlen;i++){
		v=0;
		for(j=0;j<step;j++){
			v <<= step;
			v += md[i*step+j];
		}
		str[i]=g_string[(v/(daynum+10))%g_stringsize];
	}
	str[g_charlen]=0;
	//printf("buf[%s] vcode[%s] str[%s] day[%d]\n",buf,vcodebuf,str,daynum);
	return 0;
}

int vcode_getstr(const char *vcodebuf,char *str)
{
	if(!vcodebuf || !str){
		fprintf(stderr,"vcode_getstr args invalid!\n");
		return -1;
	}
	if(g_init!=1){
		fprintf(stderr,"vcode not init!\n");
		return -1;
	}
	time_t curtime = time(NULL);
	struct tm ltm;
	curtime -= 3600 * g_changehour;
	localtime_r( &curtime,&ltm);
	int daynum = ltm.tm_yday;
	return _vcode_getstr(vcodebuf,str,daynum);
}

int vcode_verify(const char *vcodebuf,const char *str,const unsigned int span_secs)
{
	if(!vcodebuf || !str || strlen(str)!=g_charlen){
		fprintf(stderr,"vcode_verify args invalid!\n");	
		return -1;
	}
	if(g_init!=1){
		fprintf(stderr,"vcode not init!\n");
		return -1;
	}
	
	//const int CODE_SIZE = 100;
	//char code[CODE_SIZE + 1] = {0};
	//int ret = decode_hex(vcodebuf, (unsigned char*)code, CODE_SIZE);
	//if (ret < 0)
	//	return -1;
	
	char rstrbuf[10];
	time_t curtime = time(NULL);
	curtime -= 3600*g_changehour;
	struct tm ltm;
	localtime_r( &curtime,&ltm);
	int day = abs(ltm.tm_yday);
	_vcode_getstr(vcodebuf,rstrbuf,day);
	if( strcasecmp(rstrbuf,str)==0 )
		return 0;
	curtime -= span_secs;
	localtime_r(&curtime, &ltm );
	int day1 = abs(ltm.tm_yday);
	curtime += 2*span_secs;
	localtime_r(&curtime,&ltm);
	int day2 = abs(ltm.tm_yday);
	if( day!=day1 /*|| day!=day2*/ )
	{
		_vcode_getstr(vcodebuf,rstrbuf,day-1);
		if( strcasecmp( rstrbuf,str)==0 )
			return 0;
	}
	if( /*day!=day1 ||*/ day!=day2 )
	{
		_vcode_getstr(vcodebuf,rstrbuf,day+1);
		if( strcasecmp( rstrbuf,str)==0 )
			return 0;
	}
	return -1;
}

/**
 * 将字符串做签名处理
**/
static void vcode_sign(const char* str, unsigned int length, u_int* high/*签名后的高位*/, u_int* low/*签名后的低位*/)
{
	if (str == NULL || length == 0 || high == NULL || low == NULL)
		return;

	//creat_sign_fs64((char*)str, length, high, low);
	int i;	
	const int LEN = 16;
	unsigned char md[LEN + 1];
	MD5((unsigned const char*)str, length, md);

	md[LEN] = 0;
	int half = LEN >> 1; // LEN / 2
	int quater = half >> 1; // LEN / 4
	
	for (i = 0; i < half; i++)
	{
		md[i] ^= md[i + half];
	}
	
	memcpy(high, md, quater);
	memcpy(low, md + quater, quater);
}

