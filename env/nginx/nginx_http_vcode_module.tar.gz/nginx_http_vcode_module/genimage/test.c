#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include "gd.h"
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <sys/types.h>
#include <unistd.h>
#include "genimage.h"
#define HEIGHT 40
#define WIDTH 120
#define IMGCAPTCHA_IMAGE_BUF_SIZE 1024000


int
main(int argc, char *argv[])
{
	if (argc != 2) {
		printf("usage: ./test HKUK\n");
		return -1;
	}

	char code[4];

	//argv��Ҫ4���ַ�
	strncpy(code, argv[1], 4);

	int size = 0;
	int ret = 0;
	//����洢ͼƬ��buf
	char *image_buf = (char *) malloc(IMGCAPTCHA_IMAGE_BUF_SIZE);
	memset(image_buf, 0, IMGCAPTCHA_IMAGE_BUF_SIZE);

	//��ʼ����֤�����,���ȺͿ��ȵ�������Ч
	ret = genimage_init("./captcha_fonts_imgs/", 120, 40, 0, IMGCAPTCHA_NORMAL_FONT | IMGCAPTCHA_SPECIAL_FONT, 
		IMGCAPTCHA_SET_CURVE);
	if (ret < 0) {
		printf("genimage_init error!");
		return -1;
	}
	//������֤��ͼƬ
	size = captcha_gen(0, code, 4, image_buf, IMGCAPTCHA_IMAGE_BUF_SIZE);
	if (ret < 0) {
		printf("genimage error!\n");
		return -1;
	}
	//�洢��֤��ͼƬ
	char filename[256] = "test.jpg";
	int fd = open(filename, O_RDWR | O_CREAT, 0644);
	if (fd <= 0) {
		printf("open file:%s error![%m]\n", filename);
		return -1;
	}
	ret = write(fd, image_buf, size);
	if (ret != size) {
		printf("write error! ret=%d size=%d\n", ret, size);
		close(fd);
		return -1;
	}
	close(fd);

	return 0;
}
